var e_2=document.getElementsByClassName('e_2');
var e_1=document.getElementsByClassName('e_1');
var e_4=document.getElementsByClassName('e_4');
var e_3=document.getElementsByClassName('e_3');
var e_5=document.getElementsByClassName('e_5');
var e_6=document.getElementsByClassName('e_6');
var e_7=document.getElementsByClassName('e_7');
var e_8=document.getElementsByClassName('e_8');
var e_9=document.getElementsByClassName('e_9');
var e_10=document.getElementsByClassName('e_10');

e_2[0].onmousemove = function () {   
    e_2[0].style.color="red"; 
    e_1[0].style.color="red"; 
}
e_2[0].onmouseout= function () {   
    e_2[0].style.color="#616187"; 
    e_1[0].style.color="#616187";
}
e_1[0].onmousemove = function () {   
    e_1[0].style.color="red"; 
    e_2[0].style.color="red"; 
}
e_1[0].onmouseout= function () {   
    e_1[0].style.color="#616187"; 
    e_2[0].style.color="#616187";
}

//---------------------------------------------------------
e_6[0].onmousemove = function () {   
    e_6[0].style.color="red"; 
    e_5[0].style.color="red"; 
}
e_6[0].onmouseout= function () {   
    e_6[0].style.color="#616187"; 
    e_5[0].style.color="#616187";
}
e_5[0].onmousemove = function () {   
    e_5[0].style.color="red"; 
    e_6[0].style.color="red"; 
}
e_5[0].onmouseout= function () {   
    e_5[0].style.color="#616187"; 
    e_6[0].style.color="#616187";
}
//-----------------------------------------------------------------
e_4[0].onmousemove = function () {   
    e_4[0].style.color="red"; 
    e_3[0].style.color="red"; 
}
e_4[0].onmouseout= function () {   
    e_4[0].style.color="#616187"; 
    e_3[0].style.color="#616187";
}
e_3[0].onmousemove = function () {   
    e_3[0].style.color="red"; 
    e_4[0].style.color="red"; 
}
e_3[0].onmouseout= function () {   
    e_3[0].style.color="#616187"; 
    e_4[0].style.color="#616187";
}
//--------------------------------------------------------------------
e_8[0].onmousemove = function () {   
    e_8[0].style.color="red"; 
    e_7[0].style.color="red"; 
}
e_8[0].onmouseout= function () {   
    e_8[0].style.color="#616187"; 
    e_7[0].style.color="#616187";
}
e_7[0].onmousemove = function () {   
    e_7[0].style.color="red"; 
    e_8[0].style.color="red"; 
}
e_7[0].onmouseout= function () {   
    e_7[0].style.color="#616187"; 
    e_8[0].style.color="#616187";
}
//-----------------------------------------------------
e_10[0].onmousemove = function () {   
    e_10[0].style.color="red"; 
    e_9[0].style.color="red"; 
}
e_10[0].onmouseout= function () {   
    e_10[0].style.color="#616187"; 
    e_9[0].style.color="#616187";
}
e_9[0].onmousemove = function () {   
    e_9[0].style.color="red"; 
    e_10[0].style.color="red"; 
}
e_9[0].onmouseout= function () {   
    e_9[0].style.color="#616187"; 
    e_10[0].style.color="#616187";
}
//---------------------------------------------
var t_4=document.getElementsByClassName('t_4')[0];
var t_5=document.getElementsByClassName('t_5')[0];
var t_6=document.getElementsByClassName('t_6')[0];
t_4.onmousemove= function(){ 
    t_5.style.color="#fff"; 
    t_6.style.color="#fff"; 
    t_4.style. background= "#ff6700"; 
    t_4.style.transition = "0.5s";
}
t_4.onmouseout= function(){   
    t_5.style.color="#ff6700"; 
    t_6.style.color="#ff6700";  
    t_4.style. background= "#fff"; 
    t_4.style.transition = "0.5s"; 
}
//--------------------------------------------------


//--------------------------------------------------------------
