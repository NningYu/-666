var xiala=document.getElementById("xiala");
var nav=document.getElementsByClassName("nav");
var im=document.getElementsByClassName("im");
nav[0].onmousemove = function () {
    // xiala.style.borderTop="2px solid #e0e0e0";
    xiala.style.height = "229px";
    xiala.style.transition = "0.5s";
    nav[0].style.color="red";                   
}
xiala.onmousemove=function () {
    // xiala.style.borderTop="2px solid #e0e0e0";
    xiala.style.height = "229px";
    xiala.style.transition = "0.5s"; 
    nav[0].style.color="red";    
}
xiala.onmouseout = function () {
    xiala.style.height = "0px"; 
    xiala.style.transition = "0.5s";
    // xiala.style.borderTop="2px solid #fff";
    nav[0].style.color="#333";
}
nav[0].onmouseout = function () {
    xiala.style.height = "0px"; 
    xiala.style.transition = "0.5s";
    // xiala.style.borderTop="2px solid #fff";
    nav[0].style.color="#333";                
}
//-------------------------------------------------------
var xialaa=document.getElementById("xialaa");
var navv=document.getElementsByClassName("navv");
var imm=document.getElementsByClassName("imm");
navv[0].onmousemove = function () {
    // xialaa.style.borderTop="2px solid #e0e0e0";
    xialaa.style.height = "229px";
    xialaa.style.transition = "0.5s"; 
    navv[0].style.color="red";                  
}
xialaa.onmousemove=function () {
    // xialaa.style.borderTop="2px solid #e0e0e0";
    xialaa.style.height = "229px";
    xialaa.style.transition = "0.5s";  
    navv[0].style.color="red";   
}
xialaa.onmouseout = function () {
    xialaa.style.height = "0px"; 
    xialaa.style.transition = "0.5s";
    // xialaa.style.borderTop="2px solid #fff";
    navv[0].style.color="#333";  
}
navv[0].onmouseout = function () {
    xialaa.style.height = "0px"; 
    // xialaa.style.top = "-250px"; 
    xialaa.style.transition = "0.5s";
    // xialaa.style.borderTop="2px solid #fff";  
    navv[0].style.color="#333";  
                  
}
//-------------------------------------------------------

var xialaaa=document.getElementById("xialaaa");
var navvv=document.getElementsByClassName("navvv");
var immm=document.getElementsByClassName("immm");
navvv[0].onmousemove = function () {
    // xialaaa.style.borderTop="2px solid  transition";
    xialaaa.style.height = "229px";
    xialaaa.style.transition = "0.5s";
    navvv[0].style.color="red";                  
}
xialaaa.onmousemove=function () {
    // xialaaa.style.borderTop="2px solid   transition: ";
    xialaaa.style.height = "229px";
    xialaaa.style.transition = "0.5s";
    navvv[0].style.color="red";    
}
xialaaa.onmouseout = function () {
    xialaaa.style.height = "0px"; 
    xialaaa.style.transition = "0.5s";
    // xialaaa.style.borderTop="2px solid #fff";
    navvv[0].style.color="#333";   
}
navvv[0].onmouseout = function () {
    xialaaa.style.height = "0px"; 
    // xialaa.style.top = "-250px"; 
    xialaaa.style.transition = "0.5s";
    // xialaaa.style.borderTop="2px solid #fff"; 
    navvv[0].style.color="#333";         
}
//-------------------------------------------------------
var xialaaaa=document.getElementById("xialaaaa");
var navvvv=document.getElementsByClassName("navvvv");
var immmm=document.getElementsByClassName("immmm");
navvvv[0].onmousemove = function () {
    // xialaaaa.style.borderTop="2px solid    transition: ";
    xialaaaa.style.height = "229px";
    xialaaaa.style.transition = "0.5s";
    navvvv[0].style.color="red";                  
}
xialaaaa.onmousemove=function () {
    // xialaaaa.style.borderTop="2px solid   transition: ";
    xialaaaa.style.height = "229px";
    xialaaaa.style.transition = "0.5s";
    navvvv[0].style.color="red";    
}
xialaaaa.onmouseout = function () {
    xialaaaa.style.height = "0px"; 
    xialaaaa.style.transition = "1s";
    // xialaaaa.style.borderTop="2px solid #fff";
    navvvv[0].style.color="#333";   
}
navvvv[0].onmouseout = function () {
    xialaaaa.style.height = "0px"; 
    // xialaa.style.top = "-250px"; 
    xialaaaa.style.transition = "0.5s";
    // xialaaaa.style.borderTop="2px solid #fff"; 
    navvvv[0].style.color="#333";         
}
//-------------------------------------------------------
var xialaaaaa=document.getElementById("xialaaaaa");
var navvvvv=document.getElementsByClassName("navvvvv");
var immmmm=document.getElementsByClassName("immmmm");
navvvvv[0].onmousemove = function () {
    // xialaaaaa.style.borderTop="2px solid   transition: ";
    xialaaaaa.style.height = "229px";
    xialaaaaa.style.transition = "0.5s"; 
    navvvvv[0].style.color="red";                  
}
xialaaaaa.onmousemove=function () {
    // xialaaaaa.style.borderTop="2px solid   transition: ";
    xialaaaaa.style.height = "229px";
    xialaaaaa.style.transition = "0.5s";  
    navvvvv[0].style.color="red";   
}
xialaaaaa.onmouseout = function () {
    xialaaaaa.style.height = "0px"; 
    xialaaaaa.style.transition = "0.5s";
    // xialaaaaa.style.borderTop="2px solid #fff";
    navvvvv[0].style.color="#333";  
}
navvvvv[0].onmouseout = function () {
    xialaaaaa.style.height = "0px"; 
    // xialaa.style.top = "-250px"; 
    xialaaaaa.style.transition = "0.5s";
    // xialaaaaa.style.borderTop="2px solid #fff";  
    navvvvv[0].style.color="#333";                  
}
//-------------------------------------------------------
var xialaaaaaa=document.getElementById("xialaaaaaa");
var navvvvvv=document.getElementsByClassName("navvvvvv");
var immmmmm=document.getElementsByClassName("immmmmm");
navvvvvv[0].onmousemove = function () {

    xialaaaaaa.style.height = "229px";
    xialaaaaaa.style.transition = "0.5s"; 
    navvvvvv[0].style.color="red";                  
}
xialaaaaaa.onmousemove=function () {
    xialaaaaaa.style.height = "229px";
    xialaaaaaa.style.transition = "0.5s";  
    navvvvvv[0].style.color="red";   
}
xialaaaaaa.onmouseout = function () {
    xialaaaaaa.style.height = "0px"; 
    xialaaaaaa.style.transition = "0.5s";
    navvvvvv[0].style.color="#333";  
}
navvvvvv[0].onmouseout = function () {
    xialaaaaaa.style.height = "0px"; 
    xialaaaaaa.style.transition = "0.5s";
    navvvvvv[0].style.color="#333";                  
}
//-------------------------------------------------------
var xialaaaaaaa=document.getElementById("xialaaaaaaa");
var hhhhhhh=document.getElementsByClassName("hhhhhhh");
var navvvvvvv=document.getElementsByClassName("navvvvvvv");
navvvvvvv[0].onmousemove = function () {
    xialaaaaaaa.style.height = "229px";
    xialaaaaaaa.style.transition = "0.5s"; 
    navvvvvvv[0].style.color="red";                  
}
xialaaaaaaa.onmousemove=function () {
    xialaaaaaaa.style.height = "229px";
    xialaaaaaaa.style.transition = "0.5s";  
    navvvvvvv[0].style.color="red";   
}
xialaaaaaaa.onmouseout = function () {
    xialaaaaaaa.style.height = "0px"; 
    xialaaaaaaa.style.transition = "0.5s";
    navvvvvvv[0].style.color="#333";  
}
navvvvvvv[0].onmouseout = function () {
    xialaaaaaaa.style.height = "0px"; 
    xialaaaaaaa.style.transition = "0.5s";
    navvvvvvv[0].style.color="#333";                  
}
//-------------------------------------------------------


